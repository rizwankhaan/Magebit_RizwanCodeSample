# Magebit_RizwanCodeSample module

This is just a normal readme file to give better understanding of this module, Developed by - Rizwan Khan for Magebit

1. This is custom product inquiry module which will add one more tab in product view page.

2. Customer can submit the inquiry which will be visible to admin in the backend admin grid.

3. This Module can be enabled or disable from the store configuration.
Store-> Configuration-> Magebit-> General Configuration For Inquiry Form

4. On the frontend side form is built using tailwind css which is generated from the source using package manager, I have not got chance to work with hyva theme and developer documentation is alo very limited without license key. I have tried to use tailwind css with the form which is main css component in hyva theme. I have worked with vueStorefront extensively.

5. Due to time limit I have not included the reply to inquiry function. I would like to use the reply function on view inquiry form and admin user can submit the reply on the textarea and that will be goes to customer's email with the reply using magento email template.
