<?php
declare(strict_types=1);

namespace Magebit\RizwanCodeSample\Controller\Adminhtml\Inquiry;

use Exception;
use Magebit\RizwanCodeSample\Api\ProductInquiryRepositoryInterface;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Exception\LocalizedException;

class Delete extends Action
{
    /**
     * @var ProductInquiryRepositoryInterface
     */
    protected ProductInquiryRepositoryInterface $productInquiryRepository;

    /**
     * @param Context $context
     * @param ProductInquiryRepositoryInterface $productInquiryRepository
     */
    public function __construct(
        Context $context,
        ProductInquiryRepositoryInterface $productInquiryRepository
    ) {
        $this->productInquiryRepository = $productInquiryRepository;
        parent::__construct($context);
    }

    /**
     * @return Redirect
     */
    public function execute(): Redirect
    {
        $id = $this->getRequest()->getParam('id');
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            try {
                $this->productInquiryRepository->deleteById(intval($id));
                $this->messageManager->addSuccessMessage(__('The Inquiry has been deleted.'));
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (Exception $e) {
                $this->messageManager->addErrorMessage(__('There was a problem deleting the Inquiry'));
            }
            $resultRedirect->setPath('*/*/listing');
            return $resultRedirect;
        }

        $this->messageManager->addErrorMessage(__('We can\'t find a Inquiry to delete.'));
        $resultRedirect->setPath('*/*/listing');
        return $resultRedirect;

    }
}
