<?php
declare(strict_types=1);

namespace Magebit\RizwanCodeSample\Api;

/**
 * Interface ProductInquirySubmit
 * @package Magebit\RizwanCodeSample\Api
 */
interface ProductInquirySubmitInterface
{
    /**
     * @param mixed $data
     * @return string
     */
    public function submitProductInquiry(mixed $data): string;

}
