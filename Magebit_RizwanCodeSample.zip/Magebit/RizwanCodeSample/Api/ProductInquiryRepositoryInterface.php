<?php
declare(strict_types=1);

namespace Magebit\RizwanCodeSample\Api;

use Magebit\RizwanCodeSample\Api\Data\ProductInquiryInterface;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 *
 * @api
 */
interface ProductInquiryRepositoryInterface
{
    /**
     * Create or update a ProductInquiry.
     *
     * @param ProductInquiryInterface $productInquiry
     * @return ProductInquiryInterface
     */
    public function save(ProductInquiryInterface $productInquiry);

    /**
     * Get a ProductInquiry by Id
     *
     * @param int $id
     * @return ProductInquiryInterface
     * @throws NoSuchEntityException If ProductInquiry with the specified ID does not exist.
     * @throws LocalizedException
     */
    public function getById($id);

    /**
     * Retrieve ProductInquiry which match a specified criteria.
     *
     * @param SearchCriteriaInterface $criteria
     */
    public function getList(SearchCriteriaInterface $criteria);

    /**
     * Delete a ProductInquiry
     *
     * @param ProductInquiryInterface $productInquiry
     * @return ProductInquiryInterface
     * @throws NoSuchEntityException If ProductInquiry with the specified ID does not exist.
     * @throws LocalizedException
     */
    public function delete(ProductInquiryInterface $productInquiry);

    /**
     * Delete a ProductInquiry by Id
     *
     * @param int $id
     * @return ProductInquiryInterface
     * @throws NoSuchEntityException If ProductInquiry with the specified ID does not exist.
     * @throws LocalizedException
     */
    public function deleteById(int $id);
}
