<?php
declare(strict_types=1);

namespace Magebit\RizwanCodeSample\Api\Data;

interface ProductInquiryInterface
{
    /**
     * String constants for property names
     */
    public const ID = "id";
    public const SKU = "sku";
    public const CUSTOMER_NAME = "customer_name";
    public const CUSTOMER_EMAIL = "customer_email";
    public const INQUIRY_CONTENT = "inquiry_content";
    public const CREATED_AT = "created_at";
    public const UPDATED_AT = "updated_at";

    /**
     * @return mixed
     */
    public function getId(): mixed;

    /**
     * @param $id
     * @return void
     */
    public function setId($id): void;

    /**
     * Getter for Sku.
     *
     * @return string|null
     */
    public function getSku(): ?string;

    /**
     * Setter for Sku.
     *
     * @param string|null $sku
     *
     * @return void
     */
    public function setSku(?string $sku): void;

    /**
     * Getter for CustomerName.
     *
     * @return string|null
     */
    public function getCustomerName(): ?string;

    /**
     * Setter for CustomerName.
     *
     * @param string|null $customerName
     *
     * @return void
     */
    public function setCustomerName(?string $customerName): void;

    /**
     * Getter for CustomerEmail.
     *
     * @return string|null
     */
    public function getCustomerEmail(): ?string;

    /**
     * Setter for CustomerEmail.
     *
     * @param string|null $customerEmail
     *
     * @return void
     */
    public function setCustomerEmail(?string $customerEmail): void;

    /**
     * Getter for InquiryContent.
     *
     * @return string|null
     */
    public function getInquiryContent(): ?string;

    /**
     * Setter for InquiryContent.
     *
     * @param string|null $inquiryContent
     *
     * @return void
     */
    public function setInquiryContent(?string $inquiryContent): void;

    /**
     * Getter for CreatedAt.
     *
     * @return string|null
     */
    public function getCreatedAt(): ?string;

    /**
     * Setter for CreatedAt.
     *
     * @param string|null $createdAt
     *
     * @return void
     */
    public function setCreatedAt(?string $createdAt): void;

    /**
     * Getter for UpdatedAt.
     *
     * @return string|null
     */
    public function getUpdatedAt(): ?string;

    /**
     * Setter for UpdatedAt.
     *
     * @param string|null $updatedAt
     *
     * @return void
     */
    public function setUpdatedAt(?string $updatedAt): void;
}
