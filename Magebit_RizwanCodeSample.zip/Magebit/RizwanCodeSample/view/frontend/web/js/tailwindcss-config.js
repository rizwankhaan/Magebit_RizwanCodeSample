/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ['app/code/Magebit/RizwanCodeSample/../**/*.phtml', 'app/code/Magebit/RizwanCodeSample/../**/*.html', 'app/code/Magebit/RizwanCodeSample/../**/*.js'],
    theme: {
        extend: {},
    },
    plugins: [],
}
