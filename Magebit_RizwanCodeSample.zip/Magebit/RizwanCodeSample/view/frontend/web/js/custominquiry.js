require(["jquery", "mage/validation"], function ($) {
    $(document).ready(function () {
        $(document).on("click", "#submit_inquiry", function (e) {
            e.preventDefault();
            if ($("#product-inquiry-form").valid()) {
                const apiUrl = "rest/V1/productInquirySubmit";
                const inquiryData = {
                    data: {
                        name: $("#name").val(),
                        email: $("#email").val(),
                        content: $("#inquiryContent").val(),
                        sku: $("#product_sku").val()
                    }
                };
                $.ajax({
                    url: apiUrl,
                    type: 'POST',
                    dataType: 'json',
                    showLoader: true,
                    contentType: 'application/json',
                    data: JSON.stringify(inquiryData),
                    success: function (response) {
                        let responseData = $.parseJSON(response);
                        if (responseData.status) {
                            $('span#success_message').removeClass('hidden');
                            $("span#success_message").text(responseData.message);
                            $("#product-inquiry-form").get(0).reset()
                            setTimeout(function () {
                                $('span#success_message').addClass('hidden');
                            }, 3000);
                        } else {
                            $('span#error_message').removeClass('hidden');
                            $("span#error_message").text(responseData.message);
                            setTimeout(function () {
                                $('span#error_message').addClass('hidden');
                            }, 5000);
                        }
                    },
                    error: function () {
                        $("span#error_message").text("Some Error Encountered. Please Try again.");
                    }
                });
            }
        });
    });
});
