var config = {
    deps: [
        'Magebit_RizwanCodeSample/js/custominquiry'
    ]
};
