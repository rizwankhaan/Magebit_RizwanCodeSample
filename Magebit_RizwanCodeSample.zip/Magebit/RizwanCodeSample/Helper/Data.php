<?php
declare(strict_types=1);

namespace Magebit\RizwanCodeSample\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;

class Data extends AbstractHelper
{
    const XML_CONFIG_PATH_MAGEBIT_PRODUCTINQUIRY = 'magebit_general_config/general/enable';

    /**
     * @param Context $context
     */
    public function __construct(Context $context)
    {
        parent::__construct($context);
    }

    /**
     * @return mixed
     */
    public function getInquiryFormStatus(): mixed
    {
        return $this->getConfigValue(self::XML_CONFIG_PATH_MAGEBIT_PRODUCTINQUIRY);
    }

    /**
     * @param string $path
     * @return mixed
     */
    public function getConfigValue(string $path): mixed
    {
        return $this->scopeConfig->getValue($path);
    }

}
