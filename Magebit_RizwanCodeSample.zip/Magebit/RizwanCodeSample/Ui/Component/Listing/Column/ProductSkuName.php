<?php
declare(strict_types=1);

namespace Magebit\RizwanCodeSample\Ui\Component\Listing\Column;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Element\UiComponent\ContextInterface as ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory as UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;

class ProductSkuName extends Column
{
    private ProductRepositoryInterface $productRepository;

    /**
     * @param ProductRepositoryInterface $productRepository
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ProductRepositoryInterface $productRepository,
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        array $components = [],
        array $data = []
    ) {
        $this->productRepository = $productRepository;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * @param array $dataSource
     * @return array
     * @throws NoSuchEntityException
     */
    public function prepareDataSource(array $dataSource): array
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                if (isset($item['id'])) {
                    $productName = $this->productRepository->get($item['sku'])->getName();
                    $item['sku'] = $productName . ' | ' . $item['sku'];
                }
            }
        }
        return $dataSource;
    }

}
