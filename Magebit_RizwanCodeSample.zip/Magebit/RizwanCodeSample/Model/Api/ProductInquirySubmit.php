<?php
declare(strict_types=1);

namespace Magebit\RizwanCodeSample\Model\Api;

use Exception;
use Magebit\RizwanCodeSample\Api\ProductInquirySubmitInterface;
use Magebit\RizwanCodeSample\Helper\Data as GeneralHelper;
use Magebit\RizwanCodeSample\Model\ProductInquiryFactory;
use Magebit\RizwanCodeSample\Model\ResourceModel\ProductInquiry as InquiryResourceModel;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;

class ProductInquirySubmit implements ProductInquirySubmitInterface
{
    const MESSAGE = 'message';
    const STATUS = 'status';
    const PATH_STORE_EMAIL_FOR_MORE_INFORMATION = "Inquiry submission is disabled, Please contact us on store email.";
    private GeneralHelper $generalHelper;
    private ProductInquiryFactory $productInquiryFactory;
    private TimezoneInterface $timezoneInterface;
    private InquiryResourceModel $productInquiryResourceModel;

    /**
     * @param GeneralHelper $helper
     * @param ProductInquiryFactory $productInquiryFactory
     * @param TimezoneInterface $timezoneInterface
     * @param InquiryResourceModel $productInquiryResourceModel
     */
    public function __construct(
        GeneralHelper $helper,
        ProductInquiryFactory $productInquiryFactory,
        TimezoneInterface $timezoneInterface,
        InquiryResourceModel $productInquiryResourceModel
    ) {
        $this->generalHelper = $helper;
        $this->productInquiryFactory = $productInquiryFactory;
        $this->timezoneInterface = $timezoneInterface;
        $this->productInquiryResourceModel = $productInquiryResourceModel;
    }

    /**
     * @param mixed $data
     * @return string
     */
    public function submitProductInquiry(mixed $data): string
    {
        $response = [self::STATUS => false, "message" => ""];
        try {
            $status = $this->generalHelper->getInquiryFormStatus();
            if ($status) {
                $sku = trim($data['sku']) ?? "Blank";
                $name = trim($data['name']) ?? 'Guest Default Name';
                $email = trim($data['email']) ?? 'invalid@email.com';
                $content = $data['content'] ?? 'Default content';
                if ($name && $email && $content) {
                    $createdAtTime = $this->timezoneInterface->date()->format('Y-m-d H:i:s');
                    $inquiryModel = $this->productInquiryFactory->create();
                    $inquiryModel->setSku($sku);
                    $inquiryModel->setCustomerName($name);
                    $inquiryModel->setCustomerEmail($email);
                    $inquiryModel->setInquiryContent($content);
                    $inquiryModel->setCreatedAt($createdAtTime);
                    $this->productInquiryResourceModel->save($inquiryModel);
                    $response[self::STATUS] = true;
                    $response[self::MESSAGE] = __("Inquiry Submit Successfully");
                } else {
                    $response[self::STATUS] = false;
                    $response[self::MESSAGE] = __(self::PATH_STORE_EMAIL_FOR_MORE_INFORMATION);
                }
            } else {
                $response[self::STATUS] = false;
                $response[self::MESSAGE] = __(self::PATH_STORE_EMAIL_FOR_MORE_INFORMATION);
            }
        } catch (Exception $exception) {
            $response[self::STATUS] = false;
            $response[self::MESSAGE] = $exception->getMessage();
        }
        return json_encode($response, JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
    }

}
