<?php
declare(strict_types=1);

namespace Magebit\RizwanCodeSample\Model;

use Magebit\RizwanCodeSample\Api\Data\ProductInquiryInterface as ProductInquiryInterface;
use Magebit\RizwanCodeSample\Model\ResourceModel\ProductInquiry as ResourceModel;
use Magento\Framework\DataObject\IdentityInterface;
use Magento\Framework\Model\AbstractModel;

class ProductInquiry extends AbstractModel implements ProductInquiryInterface, IdentityInterface
{
    const CACHE_TAG = 'product_inquiry_magebit';
    /**
     * @var string
     */
    protected $_eventPrefix = 'product_inquiry_base_model';

    /**
     * Initialize model.
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }

    /**
     * @return string[]
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * @return mixed
     */
    public function getId(): mixed
    {
        return $this->getData('id');
    }

    /**
     * @return string|null
     */
    public function getSku(): ?string
    {
        return $this->getData('sku');
    }

    /**
     * @param string|null $sku
     * @return void
     */
    public function setSku(?string $sku): void
    {
        $this->setData('sku', $sku);
    }

    /**
     * @return string|null
     */
    public function getCustomerName(): ?string
    {
        return $this->getData('customer_name');
    }

    /**
     * @param string|null $customerName
     * @return void
     */
    public function setCustomerName(?string $customerName): void
    {
        $this->setData('customer_name', $customerName);
    }

    /**
     * @return string|null
     */
    public function getCustomerEmail(): ?string
    {
        return $this->getData('customer_email');
    }

    /**
     * @param string|null $customerEmail
     * @return void
     */
    public function setCustomerEmail(?string $customerEmail): void
    {
        $this->setData('customer_email', $customerEmail);
    }

    /**
     * @return string|null
     */
    public function getInquiryContent(): ?string
    {
        return $this->getData('inquiry_content');
    }

    /**
     * @param string|null $inquiryContent
     * @return void
     */
    public function setInquiryContent(?string $inquiryContent): void
    {
        $this->setData('inquiry_content', $inquiryContent);
    }

    /**
     * @return string|null
     */
    public function getCreatedAt(): ?string
    {
        return $this->getData('created_at');
    }

    /**
     * @param string|null $createdAt
     * @return void
     */
    public function setCreatedAt(?string $createdAt): void
    {
        $this->setData('created_at', $createdAt);
    }

    /**
     * @return string|null
     */
    public function getUpdatedAt(): ?string
    {
        return $this->getData('updated_at');
    }

    /**
     * @param string|null $updatedAt
     * @return void
     */
    public function setUpdatedAt(?string $updatedAt): void
    {
        $this->setData('updated_at', $updatedAt);
    }

    /**
     * @param $id
     * @return void
     */
    public function setId($id): void
    {
        $this->setData('id', $id);
    }

}
