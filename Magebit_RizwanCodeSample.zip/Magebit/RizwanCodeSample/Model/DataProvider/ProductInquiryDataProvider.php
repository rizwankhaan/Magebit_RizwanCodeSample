<?php
declare(strict_types=1);

namespace Magebit\RizwanCodeSample\Model\DataProvider;

use Magebit\RizwanCodeSample\Model\ResourceModel\ProductInquiry\CollectionFactory;
use Magento\Ui\DataProvider\AbstractDataProvider;

class ProductInquiryDataProvider extends AbstractDataProvider
{

    protected $loadedData;

    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * @return array
     */
    public function getData(): array
    {
        $items = $this->collection->getItems();
        foreach ($items as $model) {
            $this->loadedData[$model->getId()] = $model->getData();
        }
        return $this->loadedData;
    }
}
