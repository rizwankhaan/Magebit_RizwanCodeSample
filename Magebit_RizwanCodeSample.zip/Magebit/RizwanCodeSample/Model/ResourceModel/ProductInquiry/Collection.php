<?php
declare(strict_types=1);

namespace Magebit\RizwanCodeSample\Model\ResourceModel\ProductInquiry;

use Magebit\RizwanCodeSample\Model\ProductInquiry as Model;
use Magebit\RizwanCodeSample\Model\ResourceModel\ProductInquiry as ResourceModel;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_eventPrefix = 'product_inquiry_base_collection';

    /**
     * Initialize collection model.
     */
    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}
