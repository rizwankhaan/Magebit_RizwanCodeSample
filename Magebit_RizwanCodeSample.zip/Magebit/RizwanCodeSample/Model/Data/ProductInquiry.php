<?php
declare(strict_types=1);

namespace Magebit\RizwanCodeSample\Model\Data;

use Magebit\RizwanCodeSample\Api\Data\ProductInquiryInterface;
use Magento\Framework\DataObject;

class ProductInquiry extends DataObject implements ProductInquiryInterface
{
    /**
     * Getter for Id.
     *
     * @return int|null
     */
    public function getId(): ?int
    {
        return $this->getData(self::ID) === null ? null
            : (int)$this->getData(self::ID);
    }

    /**
     * Setter for Id.
     *
     * @param int|null $id
     *
     * @return void
     */
    public function setId($id): void
    {
        $this->setData(self::ID, $id);
    }

    /**
     * Getter for Sku.
     *
     * @return string|null
     */
    public function getSku(): ?string
    {
        return $this->getData(self::SKU);
    }

    /**
     * Setter for Sku.
     *
     * @param string|null $sku
     *
     * @return void
     */
    public function setSku(?string $sku): void
    {
        $this->setData(self::SKU, $sku);
    }

    /**
     * Getter for CustomerName.
     *
     * @return string|null
     */
    public function getCustomerName(): ?string
    {
        return $this->getData(self::CUSTOMER_NAME);
    }

    /**
     * Setter for CustomerName.
     *
     * @param string|null $customerName
     *
     * @return void
     */
    public function setCustomerName(?string $customerName): void
    {
        $this->setData(self::CUSTOMER_NAME, $customerName);
    }

    /**
     * Getter for CustomerEmail.
     *
     * @return string|null
     */
    public function getCustomerEmail(): ?string
    {
        return $this->getData(self::CUSTOMER_EMAIL);
    }

    /**
     * Setter for CustomerEmail.
     *
     * @param string|null $customerEmail
     *
     * @return void
     */
    public function setCustomerEmail(?string $customerEmail): void
    {
        $this->setData(self::CUSTOMER_EMAIL, $customerEmail);
    }

    /**
     * Getter for InquiryContent.
     *
     * @return string|null
     */
    public function getInquiryContent(): ?string
    {
        return $this->getData(self::INQUIRY_CONTENT);
    }

    /**
     * Setter for InquiryContent.
     *
     * @param string|null $inquiryContent
     *
     * @return void
     */
    public function setInquiryContent(?string $inquiryContent): void
    {
        $this->setData(self::INQUIRY_CONTENT, $inquiryContent);
    }

    /**
     * Getter for CreatedAt.
     *
     * @return string|null
     */
    public function getCreatedAt(): ?string
    {
        return $this->getData(self::CREATED_AT);
    }

    /**
     * Setter for CreatedAt.
     *
     * @param string|null $createdAt
     *
     * @return void
     */
    public function setCreatedAt(?string $createdAt): void
    {
        $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Getter for UpdatedAt.
     *
     * @return string|null
     */
    public function getUpdatedAt(): ?string
    {
        return $this->getData(self::UPDATED_AT);
    }

    /**
     * Setter for UpdatedAt.
     *
     * @param string|null $updatedAt
     *
     * @return void
     */
    public function setUpdatedAt(?string $updatedAt): void
    {
        $this->setData(self::UPDATED_AT, $updatedAt);
    }
}
